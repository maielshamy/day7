import React from "react";

const Home = () => {
  return (
    <div className="HOME" style={{ textAlign: "center" }}>
      <h1>WELCOME TO HOME PAGE</h1>
    </div>
  );
};

export default Home;
