import React from "react";

const Contact = () => {
  return (
    <div className="contact" style={{ textAlign: "center" }}>
      {" "}
      <h1> WELCOME TO CONTACT PAGE!</h1>
    </div>
  );
};

export default Contact;
